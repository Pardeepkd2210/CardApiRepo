﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CardsApi.Models.Response
{
   public class BaseReponse
    {
        [Display(Order = 0)]
        public Boolean Success { get; set; }
        [Display(Order = 1)]
        public string ErrorMsg { get; set; }
    }
}
