﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardsApi.Models
{
    public class Legality
    {
        public string format { get; set; }
        public string legality { get; set; }
    }
}
