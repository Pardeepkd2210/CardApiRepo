﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardsApi.Models
{
    public class Ruling
    {
        public string date { get; set; }
        public string text { get; set; }
    }
}
